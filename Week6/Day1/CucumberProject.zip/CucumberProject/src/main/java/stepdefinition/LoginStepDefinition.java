package stepdefinition;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginStepDefinition extends BaseClass {
	
	
    @When("Enter the username as {string}")
	public void enter_the_username_as_demosalesmanager(String username) {
		driver.findElement(By.id("username")).sendKeys(username);
	}

	@When("Enter the password as {string}")
	public void enter_the_password_as_crmsfa(String password) {
		driver.findElement(By.id("password")).sendKeys(password);
	}

	@When("Click on the login button")
	public void click_on_the_login_button() {
		driver.findElement(By.className("decorativeSubmit")).click();
	}

	@Then("It should navigate to the next page")
	public void it_should_navigate_to_the_next_page() {
		String text = driver.findElement(By.xpath("//h2[text()='Welcome ']")).getText();
		if (text.contains("Welcome")) {
			System.out.println("Navigated to next page");
		}

		else {
			System.out.println("Not Navigated");
		}
	}
	@When("It displays error message")
	public void it_displays_error_message() {
	  String text = driver.findElement(By.xpath("//p[text()='The Following Errors Occurred:']")).getText();
	if (text.contains("Following")) {
		System.out.println("Error message is displayed");
	}
	else {
		System.out.println("Error message not displayed");
	}
	
	}
	

}
