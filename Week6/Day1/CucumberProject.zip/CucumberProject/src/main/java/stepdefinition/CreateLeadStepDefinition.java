package stepdefinition;

import org.openqa.selenium.By;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
public class CreateLeadStepDefinition extends BaseClass {
	

@When("Click on CRMSFA link")
public void click_on_crmsfa_link() {
	driver.findElement(By.linkText("CRM/SFA")).click();
}
@When("Click on Leads link")
public void click_on_leads_link() {
	driver.findElement(By.linkText("Leads")).click();
}
@When("Click on CreateLead link")
public void click_on_create_lead_link() {
	driver.findElement(By.linkText("Create Lead")).click();
}
@When("Enter the companyname as (.*)$")
public void enter_the_companyname_as_test_leaf(String cName) {
	driver.findElement(By.id("createLeadForm_companyName")).sendKeys(cName);
}
@When("Enter the firstname as (.*)$")
public void enter_the_firstname_as_vineeth(String fName) {
	driver.findElement(By.id("createLeadForm_firstName")).sendKeys(fName);
}
@When("Enter the lastname as (.*)$")
public void enter_the_lastname_as_rajendran(String lName) {
	driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lName);
}
@When("Click on the CreateLead button")
public void click_on_the_create_lead_button() {
	 driver.findElement(By.name("submitButton")).click();
}
@Then("Lead should be created")
public void lead_should_be_created() {
    System.out.println("Lead is Created");
}

}
