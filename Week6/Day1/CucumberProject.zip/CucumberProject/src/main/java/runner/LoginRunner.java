package runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import stepdefinition.BaseClass;

@CucumberOptions(features="src/main/java/features", glue="stepdefinition", monochrome=true, publish=true)
public class LoginRunner extends BaseClass {

}



//To remove unwanted junk char in console - monochrome
//To get the cucumber report in console - publish