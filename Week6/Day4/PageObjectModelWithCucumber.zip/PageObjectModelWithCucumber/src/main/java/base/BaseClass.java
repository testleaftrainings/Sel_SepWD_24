package base;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadExcel;

public class BaseClass extends AbstractTestNGCucumberTests{
	
	//public ChromeDriver driver;
	
	public static final ThreadLocal<ChromeDriver> cDriver=new ThreadLocal<ChromeDriver>();
	public String fileName;
	
	//Setter
	public void setDriver() {
		cDriver.set(new ChromeDriver());
	}
	//Getter
	
	public ChromeDriver getDriver() {
		return cDriver.get();
	}
	
	@BeforeMethod
	public void preConditions() {
		//driver =new ChromeDriver();
		setDriver();
		getDriver().get("http://leaftaps.com/opentaps/control/main");
		getDriver().manage().window().maximize();
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(30));

	}
	
	@AfterMethod
	public void postConditions() {
		getDriver().close();
}
	
	@DataProvider(name="fetchData")
	public String[][] sendData() throws IOException {
		return ReadExcel.readData(fileName);

	}
	
}
