package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class TC_001CreateLead extends BaseClass {
	
	@BeforeTest
	public void setValues() {
		fileName="CreateLead";

	}
	
	
	
	@Test(dataProvider = "fetchData")
	public void runCreateLead(String uName, String pWord, String cName,String fName,String lName) {
		LoginPage lp=new LoginPage(driver);
		
		lp.enterUsername(uName)
		.enterPassword(pWord)
		.clickLoginButton()
		.clickCRMSFA()
		.clickLeadsLink()
		.clickCreateLead()
		.enterCompanyname(cName)
		.enterFirstname(fName)
		.enterLastname(lName)
		.enterCreateLeadButton()
		.verifyLead();
	}

}
