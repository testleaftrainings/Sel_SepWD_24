package base;

public class LearnConstructor {
	
	int empId;
	String name;
	
	public LearnConstructor() {
		System.out.println("Its a Default Constructor");
	}
	
	public LearnConstructor(int empId,String name) {
		this();
		System.out.println("Its a parameterized constructor");
		this.empId=empId;
		this.name=name;
		//global=local;
		//global = 21
		//global = "Vineeth"
	}
	
	public static void main(String[] args) {
		//LearnConstructor lc=new LearnConstructor();
		LearnConstructor lc1=new LearnConstructor(21, "Vineeth");
		System.out.println(lc1.empId);
		System.out.println(lc1.name);
    }
}
